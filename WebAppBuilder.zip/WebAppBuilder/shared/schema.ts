import { pgTable, text, serial, integer, decimal, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum("user_role", ["manager", "client"]);
export const reservationStatusEnum = pgEnum("reservation_status", ["en_cours", "annulee", "validee"]);
export const roomStatusEnum = pgEnum("room_status", ["disponible", "occupee", "maintenance"]);

// Tables
export const hotels = pgTable("hotels", {
  id: serial("id").primaryKey(),
  nom: text("nom").notNull(),
  adresse: text("adresse").notNull(),
  telephone: text("telephone").notNull(),
  codeUnique: text("code_unique").notNull().unique(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  description: text("description").notNull(),
  prix: decimal("prix", { precision: 10, scale: 2 }).notNull(),
});

export const chambres = pgTable("chambres", {
  id: serial("id").primaryKey(),
  numero: text("numero").notNull().unique(),
  telephone: text("telephone"),
  categorieId: integer("categorie_id").references(() => categories.id).notNull(),
  statut: roomStatusEnum("statut").default("disponible").notNull(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  nom: text("nom").notNull(),
  prenom: text("prenom").notNull(),
  email: text("email").notNull().unique(),
  telephone: text("telephone"),
  motDePasse: text("mot_de_passe").notNull(),
  role: userRoleEnum("role").default("client").notNull(),
});

export const prestations = pgTable("prestations", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  designation: text("designation").notNull(),
  prix: decimal("prix", { precision: 10, scale: 2 }).notNull(),
});

export const reservations = pgTable("reservations", {
  id: serial("id").primaryKey(),
  etat: reservationStatusEnum("etat").default("en_cours").notNull(),
  dateReservation: timestamp("date_reservation").defaultNow().notNull(),
  dateArrivee: timestamp("date_arrivee").notNull(),
  dateDepart: timestamp("date_depart").notNull(),
  chambreId: integer("chambre_id").references(() => chambres.id).notNull(),
  clientId: integer("client_id").references(() => users.id).notNull(),
  prixTotal: decimal("prix_total", { precision: 10, scale: 2 }).notNull(),
});

export const reservationPrestations = pgTable("reservation_prestations", {
  id: serial("id").primaryKey(),
  reservationId: integer("reservation_id").references(() => reservations.id).notNull(),
  prestationId: integer("prestation_id").references(() => prestations.id).notNull(),
});

// Insert Schemas
export const insertHotelSchema = createInsertSchema(hotels).omit({ id: true });
export const insertCategorySchema = createInsertSchema(categories).omit({ id: true });
export const insertChambreSchema = createInsertSchema(chambres).omit({ id: true });
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertPrestationSchema = createInsertSchema(prestations).omit({ id: true });
export const insertReservationSchema = createInsertSchema(reservations).omit({ 
  id: true, 
  dateReservation: true 
});
export const insertReservationPrestationSchema = createInsertSchema(reservationPrestations).omit({ id: true });

// Login schema
export const loginSchema = z.object({
  email: z.string().email(),
  motDePasse: z.string().min(1),
});

// Types
export type Hotel = typeof hotels.$inferSelect;
export type InsertHotel = z.infer<typeof insertHotelSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Chambre = typeof chambres.$inferSelect;
export type InsertChambre = z.infer<typeof insertChambreSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Prestation = typeof prestations.$inferSelect;
export type InsertPrestation = z.infer<typeof insertPrestationSchema>;

export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = z.infer<typeof insertReservationSchema>;

export type ReservationPrestation = typeof reservationPrestations.$inferSelect;
export type InsertReservationPrestation = z.infer<typeof insertReservationPrestationSchema>;

export type LoginData = z.infer<typeof loginSchema>;
