import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { insertChambreSchema } from "@shared/schema";
import type { Category, Chambre, InsertChambre } from "@shared/schema";

interface RoomModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  room?: Chambre | null;
  categories: Category[];
  onClose: () => void;
}

export function RoomModal({ open, onOpenChange, room, categories, onClose }: RoomModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertChambre>({
    resolver: zodResolver(insertChambreSchema),
    defaultValues: {
      numero: room?.numero || "",
      telephone: room?.telephone || "",
      categorieId: room?.categorieId || 0,
      statut: room?.statut || "disponible",
    },
  });

  const createRoom = useMutation({
    mutationFn: async (data: InsertChambre) => {
      const response = await fetch("/api/chambres", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chambres"] });
      toast({ title: "Chambre créée avec succès" });
      onClose();
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateRoom = useMutation({
    mutationFn: async (data: InsertChambre) => {
      console.log("Sending update data:", data);
      const response = await fetch(`/api/chambres/${room!.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        console.error("Update error response:", error);
        throw new Error(error.message || "Erreur lors de la mise à jour");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chambres"] });
      toast({ title: "Chambre mise à jour avec succès" });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertChambre) => {
    if (room) {
      updateRoom.mutate(data);
    } else {
      createRoom.mutate(data);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {room ? "Modifier la chambre" : "Ajouter une chambre"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="numero">Numéro de chambre</Label>
            <Input
              id="numero"
              placeholder="101"
              {...form.register("numero")}
            />
            {form.formState.errors.numero && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.numero.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="telephone">Téléphone</Label>
            <Input
              id="telephone"
              placeholder="+221 77 123 45 67"
              {...form.register("telephone")}
            />
            {form.formState.errors.telephone && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.telephone.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="categorieId">Catégorie</Label>
            <Select
              value={form.watch("categorieId")?.toString()}
              onValueChange={(value) => form.setValue("categorieId", parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionnez une catégorie" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.description} ({category.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.categorieId && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.categorieId.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="statut">Statut</Label>
            <Select
              value={form.watch("statut")}
              onValueChange={(value) => form.setValue("statut", value as any)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionnez un statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="disponible">Disponible</SelectItem>
                <SelectItem value="occupee">Occupée</SelectItem>
                <SelectItem value="maintenance">Maintenance</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button
              type="submit"
              disabled={createRoom.isPending || updateRoom.isPending}
            >
              {createRoom.isPending || updateRoom.isPending
                ? "Enregistrement..."
                : room
                ? "Modifier"
                : "Créer"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
