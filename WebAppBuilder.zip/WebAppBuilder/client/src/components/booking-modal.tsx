import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { insertReservationSchema } from "@shared/schema";
import type { Chambre, Category, InsertReservation, Prestation } from "@shared/schema";
import { z } from "zod";

const bookingSchema = insertReservationSchema.extend({
  prestations: z.array(z.number()).optional(),
});

type BookingData = z.infer<typeof bookingSchema>;

interface BookingModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  room: Chambre | null;
  category: Category | null;
  onClose: () => void;
}

export function BookingModal({ 
  open, 
  onOpenChange, 
  room, 
  category, 
  onClose 
}: BookingModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();
  const [selectedPrestations, setSelectedPrestations] = useState<number[]>([]);

  const { data: prestations = [] } = useQuery<Prestation[]>({
    queryKey: ["/api/prestations"],
    enabled: open,
  });

  const form = useForm<BookingData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      dateArrivee: new Date(),
      dateDepart: new Date(),
      chambreId: room?.id || 0,
      clientId: auth?.user?.id || 0,
      prixTotal: "0",
      etat: "en_cours",
    },
  });

  const dateArrivee = form.watch("dateArrivee");
  const dateDepart = form.watch("dateDepart");

  // Calculate total price
  const calculateTotal = () => {
    if (!category || !dateArrivee || !dateDepart) return 0;
    
    const nights = Math.ceil((new Date(dateDepart).getTime() - new Date(dateArrivee).getTime()) / (1000 * 60 * 60 * 24));
    const roomCost = parseFloat(category.prix) * nights;
    
    const prestationsCost = selectedPrestations.reduce((total, prestationId) => {
      const prestation = prestations.find(p => p.id === prestationId);
      return total + (prestation ? parseFloat(prestation.prix) * nights : 0);
    }, 0);
    
    return roomCost + prestationsCost;
  };

  const total = calculateTotal();

  // Update form when total changes
  React.useEffect(() => {
    form.setValue("prixTotal", total.toString());
  }, [total, form]);

  const createReservation = useMutation({
    mutationFn: async (data: BookingData) => {
      const response = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          ...data,
          clientId: auth?.user?.id,
          chambreId: room?.id,
        }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      toast({ 
        title: "Réservation créée avec succès",
        description: "Votre demande de réservation a été envoyée et est en cours de traitement."
      });
      onClose();
      form.reset();
      setSelectedPrestations([]);
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookingData) => {
    if (!auth?.user) {
      toast({
        title: "Connexion requise",
        description: "Vous devez être connecté pour effectuer une réservation.",
        variant: "destructive",
      });
      return;
    }
    createReservation.mutate(data);
  };

  const togglePrestation = (prestationId: number) => {
    setSelectedPrestations(prev => 
      prev.includes(prestationId) 
        ? prev.filter(id => id !== prestationId)
        : [...prev, prestationId]
    );
  };

  const nights = dateArrivee && dateDepart 
    ? Math.ceil((new Date(dateDepart).getTime() - new Date(dateArrivee).getTime()) / (1000 * 60 * 60 * 24))
    : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-screen overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Réserver une Chambre</DialogTitle>
        </DialogHeader>

        {!auth?.user ? (
          <div className="text-center py-8">
            <p className="text-gray-600 mb-4">
              Vous devez être connecté pour effectuer une réservation.
            </p>
            <Button onClick={onClose}>
              Se connecter
            </Button>
          </div>
        ) : (
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="dateArrivee">Date d'arrivée</Label>
                <Input
                  id="dateArrivee"
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  {...form.register("dateArrivee", { valueAsDate: true })}
                />
                {form.formState.errors.dateArrivee && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.dateArrivee.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="dateDepart">Date de départ</Label>
                <Input
                  id="dateDepart"
                  type="date"
                  min={dateArrivee ? new Date(new Date(dateArrivee).getTime() + 86400000).toISOString().split('T')[0] : undefined}
                  {...form.register("dateDepart", { valueAsDate: true })}
                />
                {form.formState.errors.dateDepart && (
                  <p className="text-sm text-red-600 mt-1">
                    {form.formState.errors.dateDepart.message}
                  </p>
                )}
              </div>
            </div>

            {room && category && (
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-gray-900 mb-2">
                    Chambre sélectionnée
                  </h3>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-600">
                        Chambre {room.numero} - {category.description}
                      </p>
                      <p className="text-sm text-gray-500">
                        €{category.prix}/nuit
                      </p>
                    </div>
                    <p className="font-medium">
                      {nights} nuit{nights > 1 ? 's' : ''}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {prestations.length > 0 && (
              <div>
                <Label className="text-base font-medium">Prestations supplémentaires</Label>
                <div className="space-y-3 mt-2">
                  {prestations.map((prestation) => (
                    <div key={prestation.id} className="flex items-center space-x-3">
                      <Checkbox
                        id={`prestation-${prestation.id}`}
                        checked={selectedPrestations.includes(prestation.id)}
                        onCheckedChange={() => togglePrestation(prestation.id)}
                      />
                      <label
                        htmlFor={`prestation-${prestation.id}`}
                        className="text-sm text-gray-700 flex-1 cursor-pointer"
                      >
                        {prestation.designation} (+€{prestation.prix}/nuit)
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Card className="bg-gray-50">
              <CardContent className="p-4">
                <h3 className="font-medium text-gray-900 mb-2">
                  Résumé de la réservation
                </h3>
                <div className="space-y-1 text-sm text-gray-600">
                  {category && (
                    <div className="flex justify-between">
                      <span>{category.description} x {nights} nuit{nights > 1 ? 's' : ''}</span>
                      <span>€{(parseFloat(category.prix) * nights).toFixed(2)}</span>
                    </div>
                  )}
                  {selectedPrestations.map(prestationId => {
                    const prestation = prestations.find(p => p.id === prestationId);
                    if (!prestation) return null;
                    return (
                      <div key={prestationId} className="flex justify-between">
                        <span>{prestation.designation} x {nights} nuit{nights > 1 ? 's' : ''}</span>
                        <span>€{(parseFloat(prestation.prix) * nights).toFixed(2)}</span>
                      </div>
                    );
                  })}
                  <div className="border-t pt-2 flex justify-between font-medium text-gray-900">
                    <span>Total</span>
                    <span>€{total.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex space-x-4">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Annuler
              </Button>
              <Button
                type="submit"
                disabled={createReservation.isPending || nights <= 0}
                className="flex-1"
              >
                {createReservation.isPending ? "Confirmation..." : "Confirmer la Réservation"}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
