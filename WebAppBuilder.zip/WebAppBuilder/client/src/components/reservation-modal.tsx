import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { insertReservationSchema } from "@shared/schema";
import type { Chambre, Category, InsertReservation, User } from "@shared/schema";

interface ReservationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  chambres: Chambre[];
  categories: Category[];
  onClose: () => void;
}

export function ReservationModal({ 
  open, 
  onOpenChange, 
  chambres, 
  categories, 
  onClose 
}: ReservationModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: clients = [] } = useQuery<User[]>({
    queryKey: ["/api/clients"],
    enabled: open,
  });

  const form = useForm<InsertReservation>({
    resolver: zodResolver(insertReservationSchema),
    defaultValues: {
      dateArrivee: new Date(),
      dateDepart: new Date(),
      chambreId: 0,
      clientId: 0,
      prixTotal: "0",
      etat: "en_cours",
    },
  });

  const selectedChambreId = form.watch("chambreId");
  const dateArrivee = form.watch("dateArrivee");
  const dateDepart = form.watch("dateDepart");

  // Calculate total price when dates or room change
  const calculateTotal = () => {
    if (!selectedChambreId || !dateArrivee || !dateDepart) return;
    
    const chambre = chambres.find(c => c.id === selectedChambreId);
    if (!chambre) return;
    
    const category = categories.find(c => c.id === chambre.categorieId);
    if (!category) return;
    
    const nights = Math.ceil((new Date(dateDepart).getTime() - new Date(dateArrivee).getTime()) / (1000 * 60 * 60 * 24));
    const total = parseFloat(category.prix) * nights;
    
    form.setValue("prixTotal", total.toString());
  };

  // Recalculate total when dependencies change
  React.useEffect(() => {
    calculateTotal();
  }, [selectedChambreId, dateArrivee, dateDepart]);

  const createReservation = useMutation({
    mutationFn: async (data: InsertReservation) => {
      const response = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      toast({ title: "Réservation créée avec succès" });
      onClose();
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertReservation) => {
    createReservation.mutate(data);
  };

  const availableRooms = chambres.filter(c => c.statut === "disponible");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Nouvelle Réservation</DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dateArrivee">Date d'arrivée</Label>
              <Input
                id="dateArrivee"
                type="date"
                {...form.register("dateArrivee", { valueAsDate: true })}
              />
              {form.formState.errors.dateArrivee && (
                <p className="text-sm text-red-600 mt-1">
                  {form.formState.errors.dateArrivee.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="dateDepart">Date de départ</Label>
              <Input
                id="dateDepart"
                type="date"
                {...form.register("dateDepart", { valueAsDate: true })}
              />
              {form.formState.errors.dateDepart && (
                <p className="text-sm text-red-600 mt-1">
                  {form.formState.errors.dateDepart.message}
                </p>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="chambreId">Chambre</Label>
            <Select
              value={form.watch("chambreId")?.toString()}
              onValueChange={(value) => form.setValue("chambreId", parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionnez une chambre" />
              </SelectTrigger>
              <SelectContent>
                {availableRooms.map((chambre) => {
                  const category = categories.find(c => c.id === chambre.categorieId);
                  return (
                    <SelectItem key={chambre.id} value={chambre.id.toString()}>
                      Chambre {chambre.numero} - {category?.description} (€{category?.prix}/nuit)
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            {form.formState.errors.chambreId && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.chambreId.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="clientId">Client</Label>
            <Select
              value={form.watch("clientId")?.toString()}
              onValueChange={(value) => form.setValue("clientId", parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionnez un client" />
              </SelectTrigger>
              <SelectContent>
                {clients.map((client) => (
                  <SelectItem key={client.id} value={client.id.toString()}>
                    {client.prenom} {client.nom} ({client.email})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.clientId && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.clientId.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="prixTotal">Prix total (€)</Label>
            <Input
              id="prixTotal"
              type="number"
              step="0.01"
              readOnly
              {...form.register("prixTotal")}
              className="bg-gray-50"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button
              type="submit"
              disabled={createReservation.isPending}
            >
              {createReservation.isPending ? "Création..." : "Créer la réservation"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
