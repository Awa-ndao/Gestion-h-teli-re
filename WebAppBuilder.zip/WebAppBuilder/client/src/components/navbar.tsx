import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Hotel, User, LogOut } from "lucide-react";
import { useAuth, useLogout } from "@/lib/auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Navbar() {
  const [location, setLocation] = useLocation();
  const { data: auth } = useAuth();
  const logout = useLogout();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => setLocation("/"),
    });
  };

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/">
              <div className="flex items-center cursor-pointer">
                <Hotel className="h-8 w-8 text-primary mr-3" />
                <h1 className="text-xl font-bold text-gray-900">Hôtel Manager</h1>
              </div>
            </Link>
          </div>

          <div className="flex items-center space-x-6">
            {!auth?.user && (
              <>
                <Link href="/catalog">
                  <Button variant="ghost" className="text-gray-700 hover:text-primary">
                    Catalogue
                  </Button>
                </Link>
                <Link href="/login">
                  <Button>Connexion</Button>
                </Link>
              </>
            )}

            {auth?.user && (
              <>
                {auth.user.role === "client" && (
                  <>
                    <Link href="/catalog">
                      <Button variant="ghost" className="text-gray-700 hover:text-primary">
                        Catalogue
                      </Button>
                    </Link>
                    <Link href="/my-reservations">
                      <Button variant="ghost" className="text-gray-700 hover:text-primary">
                        Mes Réservations
                      </Button>
                    </Link>
                  </>
                )}

                {auth.user.role === "manager" && (
                  <Link href="/dashboard">
                    <Button variant="ghost" className="text-gray-700 hover:text-primary">
                      Tableau de Bord
                    </Button>
                  </Link>
                )}

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center space-x-2">
                      <User className="h-4 w-4" />
                      <span>{auth.user.prenom} {auth.user.nom}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Déconnexion
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
