import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Phone } from "lucide-react";
import { useAuth } from "@/lib/auth";
import type { Reservation, Chambre, Category } from "@shared/schema";

export default function ClientReservations() {
  const { data: auth } = useAuth();

  const { data: reservations = [], isLoading } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
    enabled: auth?.user?.role === "client",
  });

  const { data: chambres = [] } = useQuery<Chambre[]>({
    queryKey: ["/api/chambres"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const getStatusBadge = (status: string) => {
    const baseClasses = "font-medium";
    
    switch (status) {
      case "en_cours":
        return <Badge className={`${baseClasses} reservation-status-en_cours`}>En Cours</Badge>;
      case "validee":
        return <Badge className={`${baseClasses} reservation-status-validee`}>Validée</Badge>;
      case "annulee":
        return <Badge className={`${baseClasses} reservation-status-annulee`}>Annulée</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (auth?.user?.role !== "client") {
    return <div>Accès refusé</div>;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Chargement de vos réservations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Mes Réservations</h1>
          <p className="text-gray-600">
            Consultez l'état de vos réservations et gérez vos séjours.
          </p>
        </div>

        {reservations.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Aucune réservation
              </h3>
              <p className="text-gray-500 mb-6">
                Vous n'avez pas encore effectué de réservation.
              </p>
              <Button>
                Découvrir nos chambres
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {reservations.map((reservation) => {
              const chambre = chambres.find(c => c.id === reservation.chambreId);
              const category = categories.find(c => c.id === chambre?.categorieId);
              
              return (
                <Card key={reservation.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">
                        Réservation #{reservation.id}
                      </CardTitle>
                      {getStatusBadge(reservation.etat)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div className="flex items-center text-gray-600">
                          <MapPin className="h-5 w-5 mr-2" />
                          <div>
                            <p className="font-medium">
                              Chambre {chambre?.numero || "N/A"}
                            </p>
                            <p className="text-sm">
                              {category?.description || "Catégorie inconnue"}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center text-gray-600">
                          <Calendar className="h-5 w-5 mr-2" />
                          <div>
                            <p className="font-medium">Dates du séjour</p>
                            <p className="text-sm">
                              Du {new Date(reservation.dateArrivee).toLocaleDateString()}
                              {" "}au {new Date(reservation.dateDepart).toLocaleDateString()}
                            </p>
                          </div>
                        </div>

                        {chambre?.telephone && (
                          <div className="flex items-center text-gray-600">
                            <Phone className="h-5 w-5 mr-2" />
                            <div>
                              <p className="font-medium">Téléphone de la chambre</p>
                              <p className="text-sm">{chambre.telephone}</p>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="space-y-4">
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-medium text-gray-900 mb-2">
                            Détails de la réservation
                          </h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span>Date de réservation:</span>
                              <span>{new Date(reservation.dateReservation).toLocaleDateString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Prix par nuit:</span>
                              <span>€{category?.prix || "N/A"}</span>
                            </div>
                            <div className="border-t pt-2 flex justify-between font-medium">
                              <span>Total:</span>
                              <span>€{reservation.prixTotal}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            Voir les détails
                          </Button>
                          {reservation.etat === "en_cours" && (
                            <Button variant="outline" size="sm">
                              Modifier
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
