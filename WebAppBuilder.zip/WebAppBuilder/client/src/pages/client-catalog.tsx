import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bed, Wifi, Tv, Car, Utensils } from "lucide-react";
import { BookingModal } from "@/components/booking-modal";
import type { Category, Chambre } from "@shared/schema";

export default function ClientCatalog() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<Chambre | null>(null);

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: chambres = [] } = useQuery<Chambre[]>({
    queryKey: ["/api/chambres"],
  });

  const availableRooms = chambres.filter(room => 
    room.statut === "disponible" &&
    (selectedCategory === "all" || 
     categories.find(cat => cat.id === room.categorieId)?.code === selectedCategory)
  );

  const handleBookRoom = (room: Chambre) => {
    setSelectedRoom(room);
    setBookingModalOpen(true);
  };

  const getRoomImage = (categoryCode: string) => {
    const images = {
      "STD": "https://images.unsplash.com/photo-1611892440504-42a792e24d32?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      "PREM": "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      "DLX": "https://images.unsplash.com/photo-1590490360182-c33d57733427?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    };
    return images[categoryCode as keyof typeof images] || images.STD;
  };

  const getRoomFeatures = (categoryCode: string) => {
    const features = {
      "STD": [
        { icon: Bed, label: "Queen Size" },
        { icon: Wifi, label: "WiFi Gratuit" },
        { icon: Tv, label: "TV HD" },
      ],
      "PREM": [
        { icon: Bed, label: "King Size" },
        { icon: Wifi, label: "WiFi Gratuit" },
        { icon: Tv, label: "TV HD" },
        { icon: Car, label: "Minibar" },
      ],
      "DLX": [
        { icon: Bed, label: "King Size" },
        { icon: Wifi, label: "WiFi Gratuit" },
        { icon: Tv, label: "TV HD" },
        { icon: Car, label: "Minibar" },
        { icon: Utensils, label: "Service VIP" },
      ],
    };
    return features[categoryCode as keyof typeof features] || features.STD;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Nos Chambres</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez notre sélection de chambres confortables et élégantes, conçues pour vous offrir un séjour inoubliable.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-2">
            <div className="flex space-x-1">
              <Button
                variant={selectedCategory === "all" ? "default" : "ghost"}
                onClick={() => setSelectedCategory("all")}
              >
                Toutes
              </Button>
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.code ? "default" : "ghost"}
                  onClick={() => setSelectedCategory(category.code)}
                >
                  {category.description}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Rooms Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {availableRooms.map((room) => {
            const category = categories.find(cat => cat.id === room.categorieId);
            if (!category) return null;

            const features = getRoomFeatures(category.code);
            
            return (
              <Card key={room.id} className="overflow-hidden hover:shadow-xl transition-shadow">
                <img 
                  src={getRoomImage(category.code)} 
                  alt={`Chambre ${category.description}`}
                  className="w-full h-64 object-cover"
                />
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-900">
                      Chambre {category.description}
                    </h3>
                    <Badge className="room-status-disponible">
                      Disponible
                    </Badge>
                  </div>

                  <p className="text-gray-600 mb-4">
                    {category.description === "Standard" && "Chambre confortable avec les équipements de base. Idéale pour un séjour économique."}
                    {category.description === "Premium" && "Chambre spacieuse avec vue et équipements haut de gamme. Parfaite pour les voyageurs d'affaires."}
                    {category.description === "Suite Deluxe" && "Suite luxueuse avec salon séparé et services VIP. L'expérience ultime de notre hôtel."}
                  </p>

                  <div className="flex items-center mb-4 space-x-4">
                    {features.map((feature, index) => (
                      <div key={index} className="flex items-center text-gray-500">
                        <feature.icon className="h-4 w-4 mr-1" />
                        <span className="text-sm">{feature.label}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl font-bold text-primary">€{category.prix}</span>
                      <span className="text-gray-500">/nuit</span>
                    </div>
                    <Button onClick={() => handleBookRoom(room)}>
                      Réserver
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {availableRooms.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">
              Aucune chambre disponible pour cette catégorie.
            </p>
          </div>
        )}

        <BookingModal
          open={bookingModalOpen}
          onOpenChange={setBookingModalOpen}
          room={selectedRoom}
          category={selectedRoom ? categories.find(cat => cat.id === selectedRoom.categorieId) : null}
          onClose={() => {
            setBookingModalOpen(false);
            setSelectedRoom(null);
          }}
        />
      </div>
    </div>
  );
}
