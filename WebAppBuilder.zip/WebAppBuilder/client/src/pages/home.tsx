import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Hotel, Bed, Settings } from "lucide-react";
import { useAuth } from "@/lib/auth";

export default function Home() {
  const { data: auth } = useAuth();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="hero-gradient relative">
        <div 
          className="relative bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `linear-gradient(rgba(59, 130, 246, 0.8), rgba(99, 102, 241, 0.8)), url('https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800')`
          }}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
            <div className="text-center text-white">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Système de Gestion
                <br />
                <span className="text-yellow-300">Hôtelière</span>
              </h1>
              <p className="text-xl md:text-2xl mb-8 text-gray-100 max-w-3xl mx-auto">
                Une solution complète pour gérer vos chambres, réservations et clients avec efficacité et simplicité.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                {auth?.user?.role === "manager" ? (
                  <Link href="/dashboard">
                    <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                      <Settings className="mr-2 h-5 w-5" />
                      Espace Gestionnaire
                    </Button>
                  </Link>
                ) : (
                  <Link href="/login">
                    <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                      <Settings className="mr-2 h-5 w-5" />
                      Espace Gestionnaire
                    </Button>
                  </Link>
                )}
                <Link href="/catalog">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                    <Bed className="mr-2 h-5 w-5" />
                    Réserver une Chambre
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Fonctionnalités Principales
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Notre système offre tous les outils nécessaires pour une gestion hôtelière moderne et efficace.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 rounded-xl bg-gray-50">
              <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Bed className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Gestion des Chambres
              </h3>
              <p className="text-gray-600">
                Gérez facilement vos chambres, catégories et disponibilités en temps réel.
              </p>
            </div>

            <div className="text-center p-8 rounded-xl bg-gray-50">
              <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Hotel className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Réservations
              </h3>
              <p className="text-gray-600">
                Suivez et gérez toutes les réservations avec un système de statuts complet.
              </p>
            </div>

            <div className="text-center p-8 rounded-xl bg-gray-50">
              <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Settings className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Administration
              </h3>
              <p className="text-gray-600">
                Interface d'administration complète pour les gestionnaires d'hôtel.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
