import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  Bed, 
  Calendar, 
  TrendingUp, 
  Plus,
  Edit,
  Trash2,
  Eye,
  Check,
  X
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { RoomModal } from "@/components/room-modal";
import { CategoryModal } from "@/components/category-modal";
import { ReservationModal } from "@/components/reservation-modal";
import type { Category, Chambre, Reservation } from "@shared/schema";

export default function ManagerDashboard() {
  const { data: auth } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState("dashboard");
  const [roomModalOpen, setRoomModalOpen] = useState(false);
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [reservationModalOpen, setReservationModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Chambre | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  // Data fetching
  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    enabled: auth?.user?.role === "manager",
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: chambres = [] } = useQuery<Chambre[]>({
    queryKey: ["/api/chambres"],
  });

  const { data: reservations = [] } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
    enabled: auth?.user?.role === "manager",
  });

  const { data: clients = [] } = useQuery<any[]>({
    queryKey: ["/api/clients"],
    enabled: auth?.user?.role === "manager",
  });

  // Mutations
  const updateReservationStatus = useMutation({
    mutationFn: async ({ id, etat }: { id: number; etat: string }) => {
      const response = await fetch(`/api/reservations/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ etat }),
      });
      if (!response.ok) throw new Error("Erreur lors de la mise à jour");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      toast({ title: "Statut de réservation mis à jour" });
    },
  });

  const deleteCategory = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/categories/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Erreur lors de la suppression");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({ title: "Catégorie supprimée avec succès" });
    },
  });

  const deleteRoom = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/chambres/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Erreur lors de la suppression");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chambres"] });
      toast({ title: "Chambre supprimée avec succès" });
    },
  });

  if (auth?.user?.role !== "manager") {
    return <div>Accès refusé</div>;
  }

  const getStatusBadge = (status: string, type: "reservation" | "room") => {
    const baseClasses = "font-medium";
    
    if (type === "reservation") {
      switch (status) {
        case "en_cours":
          return <Badge className={`${baseClasses} reservation-status-en_cours`}>En Cours</Badge>;
        case "validee":
          return <Badge className={`${baseClasses} reservation-status-validee`}>Validée</Badge>;
        case "annulee":
          return <Badge className={`${baseClasses} reservation-status-annulee`}>Annulée</Badge>;
        default:
          return <Badge variant="secondary">{status}</Badge>;
      }
    } else {
      switch (status) {
        case "disponible":
          return <Badge className={`${baseClasses} room-status-disponible`}>Disponible</Badge>;
        case "occupee":
          return <Badge className={`${baseClasses} room-status-occupee`}>Occupée</Badge>;
        case "maintenance":
          return <Badge className={`${baseClasses} room-status-maintenance`}>Maintenance</Badge>;
        default:
          return <Badge variant="secondary">{status}</Badge>;
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Tableau de Bord Manager</h1>
          <p className="text-gray-600 mt-2">Vue d'ensemble de votre hôtel</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-8">
            <TabsTrigger value="dashboard">Tableau de Bord</TabsTrigger>
            <TabsTrigger value="rooms">Chambres</TabsTrigger>
            <TabsTrigger value="categories">Catégories</TabsTrigger>
            <TabsTrigger value="reservations">Réservations</TabsTrigger>
            <TabsTrigger value="clients">Clients</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Chambres Totales</p>
                      <p className="text-3xl font-bold text-gray-900">{chambres.length}</p>
                    </div>
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Bed className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Réservations Actives</p>
                      <p className="text-3xl font-bold text-gray-900">
                        {reservations.filter(r => r.etat === "validee").length}
                      </p>
                    </div>
                    <div className="p-3 bg-green-100 rounded-lg">
                      <Calendar className="h-6 w-6 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Chambres Disponibles</p>
                      <p className="text-3xl font-bold text-gray-900">
                        {chambres.filter(c => c.statut === "disponible").length}
                      </p>
                    </div>
                    <div className="p-3 bg-blue-100 rounded-lg">
                      <TrendingUp className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Clients Inscrits</p>
                      <p className="text-3xl font-bold text-gray-900">{clients.length}</p>
                    </div>
                    <div className="p-3 bg-purple-100 rounded-lg">
                      <Users className="h-6 w-6 text-purple-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Réservations Récentes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {reservations.slice(0, 5).map((reservation) => (
                      <div key={reservation.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Réservation #{reservation.id}</p>
                          <p className="text-sm text-gray-600">
                            {new Date(reservation.dateArrivee).toLocaleDateString()}
                          </p>
                        </div>
                        {getStatusBadge(reservation.etat, "reservation")}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Chambres par Statut</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { status: "disponible", count: chambres.filter(c => c.statut === "disponible").length },
                      { status: "occupee", count: chambres.filter(c => c.statut === "occupee").length },
                      { status: "maintenance", count: chambres.filter(c => c.statut === "maintenance").length },
                    ].map((item) => (
                      <div key={item.status} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900 capitalize">{item.status}</p>
                          <p className="text-sm text-gray-600">{item.count} chambres</p>
                        </div>
                        {getStatusBadge(item.status, "room")}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="categories">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Catégories de Chambres</h2>
                <p className="text-gray-600">Gérez les catégories et leurs tarifs (maximum 9 catégories)</p>
              </div>
              <Button 
                onClick={() => setCategoryModalOpen(true)}
                disabled={categories.length >= 9}
              >
                <Plus className="h-4 w-4 mr-2" />
                Ajouter une Catégorie
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categories.map((category) => (
                <Card key={category.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{category.description}</h3>
                        <p className="text-sm text-gray-500">{category.code}</p>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setEditingCategory(category);
                            setCategoryModalOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteCategory.mutate(category.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-primary">€{category.prix}/nuit</span>
                      <Badge variant="secondary">
                        {chambres.filter(c => c.categorieId === category.id).length} chambres
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="rooms">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Gestion des Chambres</h2>
                <p className="text-gray-600">Gérez vos chambres et leur disponibilité</p>
              </div>
              <Button onClick={() => setRoomModalOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Ajouter une Chambre
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Numéro</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Catégorie</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Téléphone</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {chambres.map((chambre) => {
                        const category = categories.find(c => c.id === chambre.categorieId);
                        return (
                          <tr key={chambre.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 text-sm font-medium text-gray-900">{chambre.numero}</td>
                            <td className="px-6 py-4 text-sm text-gray-500">{category?.description}</td>
                            <td className="px-6 py-4 text-sm text-gray-500">{chambre.telephone || "N/A"}</td>
                            <td className="px-6 py-4">{getStatusBadge(chambre.statut || "disponible", "room")}</td>
                            <td className="px-6 py-4 text-sm space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setEditingRoom(chambre);
                                  setRoomModalOpen(true);
                                }}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => deleteRoom.mutate(chambre.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reservations">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Gestion des Réservations</h2>
                <p className="text-gray-600">Suivez et gérez toutes les réservations</p>
              </div>
              <Button onClick={() => setReservationModalOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Nouvelle Réservation
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Réservation</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Chambre</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Dates</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                        <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {reservations.map((reservation) => {
                        const chambre = chambres.find(c => c.id === reservation.chambreId);
                        return (
                          <tr key={reservation.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4">
                              <div className="text-sm font-medium text-gray-900">#{reservation.id}</div>
                              <div className="text-sm text-gray-500">Client ID: {reservation.clientId}</div>
                            </td>
                            <td className="px-6 py-4 text-sm text-gray-500">
                              {chambre?.numero || "N/A"}
                            </td>
                            <td className="px-6 py-4">
                              <div className="text-sm text-gray-900">
                                {new Date(reservation.dateArrivee).toLocaleDateString()} - 
                                {new Date(reservation.dateDepart).toLocaleDateString()}
                              </div>
                            </td>
                            <td className="px-6 py-4">{getStatusBadge(reservation.etat, "reservation")}</td>
                            <td className="px-6 py-4 text-sm text-gray-900">€{reservation.prixTotal}</td>
                            <td className="px-6 py-4 text-sm space-x-2">
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              {reservation.etat === "en_cours" && (
                                <>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => updateReservationStatus.mutate({ 
                                      id: reservation.id, 
                                      etat: "validee" 
                                    })}
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => updateReservationStatus.mutate({ 
                                      id: reservation.id, 
                                      etat: "annulee" 
                                    })}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                </>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="clients">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Gestion des Clients</h3>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Liste des Clients</CardTitle>
                  <CardDescription>
                    Clients inscrits dans le système
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {clients.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        Aucun client inscrit pour le moment
                      </p>
                    ) : (
                      clients.map((client: any) => (
                        <div key={client.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h4 className="font-medium">{client.prenom} {client.nom}</h4>
                            <p className="text-sm text-muted-foreground">{client.email}</p>
                            <p className="text-sm text-muted-foreground">{client.telephone}</p>
                          </div>
                          <Badge variant="secondary">Client</Badge>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Modals */}
        <CategoryModal
          open={categoryModalOpen}
          onOpenChange={setCategoryModalOpen}
          category={editingCategory}
          onClose={() => {
            setCategoryModalOpen(false);
            setEditingCategory(null);
          }}
        />
        
        <RoomModal
          open={roomModalOpen}
          onOpenChange={setRoomModalOpen}
          room={editingRoom}
          categories={categories}
          onClose={() => {
            setRoomModalOpen(false);
            setEditingRoom(null);
          }}
        />

        <ReservationModal
          open={reservationModalOpen}
          onOpenChange={setReservationModalOpen}
          chambres={chambres}
          categories={categories}
          onClose={() => setReservationModalOpen(false)}
        />
      </div>
    </div>
  );
}
