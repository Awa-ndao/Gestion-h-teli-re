# Guide de Déploiement

## 📦 Déploiement sur GitHub

### Étape 1 : Préparation du repository

1. **Créer un nouveau repository sur GitHub**
   - Aller sur https://github.com/new
   - Nommer le repository (ex: `gestion-hoteliere`)
   - Ajouter une description : "Système de gestion hôtelière avec React/Express.js"
   - Laisser en Public ou Private selon vos préférences
   - **NE PAS** initialiser avec README, .gitignore, ou licence (déjà présents)

### Étape 2 : Configuration Git locale

```bash
# Initialiser git (si pas déjà fait)
git init

# Ajouter tous les fichiers
git add .

# Premier commit
git commit -m "Initial commit: Système de gestion hôtelière complet"

# Lier au repository distant
git remote add origin https://github.com/[VOTRE_USERNAME]/[NOM_DU_REPO].git

# Pousser vers GitHub
git push -u origin main
```

### Étape 3 : Configuration des variables d'environnement

Pour le déploiement, vous devrez configurer :
- `DATABASE_URL` : URL de votre base PostgreSQL de production
- Variables de session et sécurité

## 🚀 Options de déploiement

### 1. Vercel (Recommandé pour le frontend)
- Fork le repository
- Connecter à Vercel
- Configurer les variables d'environnement
- Déploiement automatique

### 2. Railway (Recommandé pour full-stack)
- Connecter le repository GitHub
- Configuration automatique PostgreSQL
- Variables d'environnement dans le dashboard

### 3. Render
- Service web pour l'application
- Service PostgreSQL pour la base
- Configuration via render.yaml

### 4. DigitalOcean App Platform
- Déploiement depuis GitHub
- Base PostgreSQL managée
- Scaling automatique

## 🔧 Scripts de déploiement

Le projet inclut les scripts npm suivants :
- `npm run dev` : Développement local
- `npm run build` : Build de production
- `npm run start` : Démarrage production
- `npm run db:push` : Migrations base de données

## 📋 Checklist pré-déploiement

- [ ] Variables d'environnement configurées
- [ ] Base de données PostgreSQL créée
- [ ] Migrations appliquées
- [ ] Tests de fonctionnement
- [ ] Données initiales insérées
- [ ] HTTPS configuré
- [ ] Domaine configuré (optionnel)

## 🔒 Sécurité

- Changer les mots de passe par défaut
- Configurer des secrets forts pour les sessions
- Utiliser HTTPS en production
- Configurer CORS approprié
- Limiter les tentatives de connexion