import { 
  users, 
  categories, 
  chambres, 
  reservations, 
  prestations,
  type User, 
  type InsertUser,
  type Category,
  type InsertCategory,
  type Chambre,
  type InsertChambre,
  type Reservation,
  type InsertReservation,
  type Prestation,
  type InsertPrestation
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  getClients(): Promise<User[]>;

  // Categories
  getCategories(): Promise<Category[]>;
  createCategory(insertCategory: InsertCategory): Promise<Category>;
  updateCategory(id: number, insertCategory: InsertCategory): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Chambres
  getChambres(): Promise<Chambre[]>;
  createChambre(insertChambre: InsertChambre): Promise<Chambre>;
  updateChambre(id: number, insertChambre: InsertChambre): Promise<Chambre | undefined>;
  deleteChambre(id: number): Promise<boolean>;

  // Prestations
  getPrestations(): Promise<Prestation[]>;
  createPrestation(insertPrestation: InsertPrestation): Promise<Prestation>;

  // Reservations
  getReservations(status?: string): Promise<Reservation[]>;
  getReservationsByClient(clientId: number, status?: string): Promise<Reservation[]>;
  createReservation(insertReservation: InsertReservation): Promise<Reservation>;
  updateReservationStatus(id: number, etat: string): Promise<Reservation | undefined>;

  // Dashboard
  getDashboardStats(): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getClients(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, "client"));
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values(insertCategory)
      .returning();
    return category;
  }

  async updateCategory(id: number, insertCategory: InsertCategory): Promise<Category | undefined> {
    const [category] = await db
      .update(categories)
      .set(insertCategory)
      .where(eq(categories.id, id))
      .returning();
    return category || undefined;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db
      .delete(categories)
      .where(eq(categories.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Chambres
  async getChambres(): Promise<Chambre[]> {
    return await db.select().from(chambres);
  }

  async createChambre(insertChambre: InsertChambre): Promise<Chambre> {
    const [chambre] = await db
      .insert(chambres)
      .values(insertChambre)
      .returning();
    return chambre;
  }

  async updateChambre(id: number, insertChambre: InsertChambre): Promise<Chambre | undefined> {
    const [chambre] = await db
      .update(chambres)
      .set(insertChambre)
      .where(eq(chambres.id, id))
      .returning();
    return chambre || undefined;
  }

  async deleteChambre(id: number): Promise<boolean> {
    const result = await db
      .delete(chambres)
      .where(eq(chambres.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Prestations
  async getPrestations(): Promise<Prestation[]> {
    return await db.select().from(prestations);
  }

  async createPrestation(insertPrestation: InsertPrestation): Promise<Prestation> {
    const [prestation] = await db
      .insert(prestations)
      .values(insertPrestation)
      .returning();
    return prestation;
  }

  // Reservations
  async getReservations(status?: string): Promise<Reservation[]> {
    if (status) {
      return await db.select().from(reservations).where(eq(reservations.etat, status as any));
    }
    return await db.select().from(reservations);
  }

  async getReservationsByClient(clientId: number, status?: string): Promise<Reservation[]> {
    if (status) {
      return await db.select().from(reservations).where(
        and(eq(reservations.clientId, clientId), eq(reservations.etat, status as any))
      );
    }
    return await db.select().from(reservations).where(eq(reservations.clientId, clientId));
  }

  async createReservation(insertReservation: InsertReservation): Promise<Reservation> {
    const [reservation] = await db
      .insert(reservations)
      .values(insertReservation)
      .returning();
    return reservation;
  }

  async updateReservationStatus(id: number, etat: string): Promise<Reservation | undefined> {
    const [reservation] = await db
      .update(reservations)
      .set({ etat: etat as any })
      .where(eq(reservations.id, id))
      .returning();
    return reservation || undefined;
  }

  // Dashboard
  async getDashboardStats(): Promise<any> {
    const totalChambres = await db.select().from(chambres);
    const totalReservations = await db.select().from(reservations);
    const totalCategories = await db.select().from(categories);
    
    return {
      totalChambres: totalChambres.length,
      totalReservations: totalReservations.length,
      totalCategories: totalCategories.length,
    };
  }
}

export const storage = new DatabaseStorage();