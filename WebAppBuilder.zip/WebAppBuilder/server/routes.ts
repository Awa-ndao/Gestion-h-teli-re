import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertCategorySchema, insertChambreSchema, insertReservationSchema, insertPrestationSchema, loginSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!(req.session as any)?.user) {
      return res.status(401).json({ message: "Non autorisé" });
    }
    next();
  };

  const requireManager = (req: any, res: any, next: any) => {
    if (!(req.session as any)?.user || (req.session as any).user.role !== "manager") {
      return res.status(403).json({ message: "Accès refusé - Gestionnaire requis" });
    }
    next();
  };

  // Auth routes
  app.post("/api/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      const user = await storage.getUserByEmail(loginData.email);
      
      if (!user) {
        return res.status(401).json({ message: "Email ou mot de passe incorrect" });
      }

      const isValidPassword = await bcrypt.compare(loginData.motDePasse, user.motDePasse);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Email ou mot de passe incorrect" });
      }

      (req.session as any).user = { id: user.id, email: user.email, role: user.role, nom: user.nom, prenom: user.prenom };
      res.json({ user: (req.session as any).user });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Un utilisateur avec cet email existe déjà" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.motDePasse, 10);
      const userToCreate = { ...userData, motDePasse: hashedPassword };
      
      const user = await storage.createUser(userToCreate);
      (req.session as any).user = { id: user.id, email: user.email, role: user.role, nom: user.nom, prenom: user.prenom };
      
      res.status(201).json({ user: (req.session as any).user });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur serveur" });
    }
  });

  app.post("/api/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ message: "Déconnexion réussie" });
    });
  });

  app.get("/api/me", requireAuth, (req, res) => {
    res.json({ user: (req.session as any).user });
  });

  // Get all clients (for managers only)
  app.get("/api/clients", requireManager, async (req, res) => {
    try {
      const clients = await storage.getClients();
      res.json(clients);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des clients" });
    }
  });

  // Categories routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des catégories" });
    }
  });

  app.post("/api/categories", requireManager, async (req, res) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      
      // Check if we already have 9 categories
      const categories = await storage.getCategories();
      if (categories.length >= 9) {
        return res.status(400).json({ message: "Maximum 9 catégories autorisées" });
      }
      
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de la catégorie" });
    }
  });

  app.put("/api/categories/:id", requireManager, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.updateCategory(id, categoryData);
      
      if (!category) {
        return res.status(404).json({ message: "Catégorie non trouvée" });
      }
      
      res.json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la mise à jour de la catégorie" });
    }
  });

  app.delete("/api/categories/:id", requireManager, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteCategory(id);
      
      if (!success) {
        return res.status(404).json({ message: "Catégorie non trouvée" });
      }
      
      res.json({ message: "Catégorie supprimée avec succès" });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la suppression de la catégorie" });
    }
  });

  // Chambres routes
  app.get("/api/chambres", async (req, res) => {
    try {
      const chambres = await storage.getChambres();
      res.json(chambres);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des chambres" });
    }
  });

  app.post("/api/chambres", requireManager, async (req, res) => {
    try {
      const chambreData = insertChambreSchema.parse(req.body);
      const chambre = await storage.createChambre(chambreData);
      res.status(201).json(chambre);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de la chambre" });
    }
  });

  app.put("/api/chambres/:id", requireManager, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      console.log("Updating chambre with ID:", id);
      console.log("Request body:", req.body);
      
      const chambreData = insertChambreSchema.parse(req.body);
      console.log("Parsed chambre data:", chambreData);
      
      const chambre = await storage.updateChambre(id, chambreData);
      console.log("Updated chambre result:", chambre);
      
      if (!chambre) {
        return res.status(404).json({ message: "Chambre non trouvée" });
      }
      
      res.json(chambre);
    } catch (error) {
      console.error("Error updating chambre:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la mise à jour de la chambre", error: String(error) });
    }
  });

  app.delete("/api/chambres/:id", requireManager, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteChambre(id);
      
      if (!success) {
        return res.status(404).json({ message: "Chambre non trouvée" });
      }
      
      res.json({ message: "Chambre supprimée avec succès" });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la suppression de la chambre" });
    }
  });

  // Prestations routes
  app.get("/api/prestations", async (req, res) => {
    try {
      const prestations = await storage.getPrestations();
      res.json(prestations);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des prestations" });
    }
  });

  app.post("/api/prestations", requireManager, async (req, res) => {
    try {
      const prestationData = insertPrestationSchema.parse(req.body);
      const prestation = await storage.createPrestation(prestationData);
      res.status(201).json(prestation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de la prestation" });
    }
  });

  // Reservations routes
  app.get("/api/reservations", requireAuth, async (req, res) => {
    try {
      const { status } = req.query;
      let reservations;
      const user = (req.session as any).user;
      
      if (user.role === "manager") {
        reservations = await storage.getReservations(status as string);
      } else {
        reservations = await storage.getReservationsByClient(user.id, status as string);
      }
      
      res.json(reservations);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des réservations" });
    }
  });

  app.post("/api/reservations", requireAuth, async (req, res) => {
    try {
      const reservationData = insertReservationSchema.parse(req.body);
      
      // For clients, ensure they can only create reservations for themselves
      const user = (req.session as any).user;
      if (user.role === "client") {
        reservationData.clientId = user.id;
      }
      
      const reservation = await storage.createReservation(reservationData);
      res.status(201).json(reservation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de la réservation" });
    }
  });

  app.put("/api/reservations/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { etat } = req.body;
      
      // Only managers can update reservation status
      const user = (req.session as any).user;
      if (user.role !== "manager") {
        return res.status(403).json({ message: "Seuls les gestionnaires peuvent modifier les réservations" });
      }
      
      const reservation = await storage.updateReservationStatus(id, etat);
      
      if (!reservation) {
        return res.status(404).json({ message: "Réservation non trouvée" });
      }
      
      res.json(reservation);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la mise à jour de la réservation" });
    }
  });

  // Dashboard stats
  app.get("/api/stats", requireManager, async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des statistiques" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
