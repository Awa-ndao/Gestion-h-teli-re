# Système de Gestion Hôtelière

Application web complète de gestion hôtelière développée avec React, Express.js et PostgreSQL.

## 🏨 Fonctionnalités

### Interface Manager
- **Tableau de bord** : Statistiques et vue d'ensemble
- **Gestion des chambres** : Création, modification, suppression
- **Gestion des catégories** : Standard, Premium, Suite Deluxe
- **Gestion des réservations** : Validation, suivi des statuts
- **Gestion des clients** : Liste et informations

### Interface Client
- **Catalogue des chambres** : Navigation par catégories
- **Système de réservation** : Sélection de dates et services
- **Prestations** : WiFi, Spa, Petit-déjeuner, Parking

## 🚀 Technologies

- **Frontend** : React 18, TypeScript, Tailwind CSS, shadcn/ui
- **Backend** : Express.js, Node.js
- **Base de données** : PostgreSQL
- **ORM** : Drizzle
- **Authentification** : Sessions avec rôles (manager/client)
- **Validation** : Zod
- **État** : TanStack Query

## 📋 Prérequis

- Node.js 18+
- PostgreSQL
- npm ou yarn

## 🛠️ Installation

1. **Cloner le repository**
   ```bash
   git clone [URL_DU_REPO]
   cd gestion-hoteliere
   ```

2. **Installer les dépendances**
   ```bash
   npm install
   ```

3. **Configuration de la base de données**
   - Créer une base PostgreSQL
   - Configurer la variable d'environnement `DATABASE_URL`

4. **Migrations**
   ```bash
   npm run db:push
   ```

5. **Données initiales**
   - Les données de test sont automatiquement créées au premier lancement

## 🏃‍♂️ Démarrage

```bash
npm run dev
```

L'application sera accessible sur `http://localhost:5000`

## 👤 Comptes de test

### Manager
- **Email** : manager@hotel.com
- **Mot de passe** : manager123

### Données pré-remplies
- 3 catégories de chambres
- 6 chambres d'exemple
- 4 prestations disponibles
- Clients sénégalais d'exemple

## 📁 Structure du projet

```
├── client/               # Interface React
│   ├── src/
│   │   ├── components/   # Composants réutilisables
│   │   ├── pages/        # Pages de l'application
│   │   └── lib/          # Utilitaires et configuration
├── server/               # API Express.js
│   ├── routes.ts         # Routes API
│   ├── storage.ts        # Couche d'accès aux données
│   └── db.ts             # Configuration base de données
├── shared/               # Types et schémas partagés
└── migrations/           # Migrations base de données
```

## 🔐 Authentification

- Système basé sur les sessions
- Deux rôles : `manager` et `client`
- Protection des routes sensibles

## 🗄️ Base de données

### Tables principales
- `users` : Utilisateurs (managers et clients)
- `categories` : Catégories de chambres
- `chambres` : Chambres d'hôtel
- `reservations` : Réservations clients
- `prestations` : Services additionnels

## 🌍 Contexte

Application adaptée pour le marché sénégalais :
- Numéros de téléphone au format +221
- Noms et prénoms sénégalais
- Interface en français

## 📝 Licence

Ce projet est sous licence MIT.

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à ouvrir des issues ou proposer des pull requests.