CREATE TYPE "public"."reservation_status" AS ENUM('en_cours', 'annulee', 'validee');--> statement-breakpoint
CREATE TYPE "public"."room_status" AS ENUM('disponible', 'occupee', 'maintenance');--> statement-breakpoint
CREATE TYPE "public"."user_role" AS ENUM('manager', 'client');--> statement-breakpoint
CREATE TABLE "categories" (
	"id" serial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"description" text NOT NULL,
	"prix" numeric(10, 2) NOT NULL,
	CONSTRAINT "categories_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "chambres" (
	"id" serial PRIMARY KEY NOT NULL,
	"numero" text NOT NULL,
	"telephone" text,
	"categorie_id" integer NOT NULL,
	"statut" "room_status" DEFAULT 'disponible' NOT NULL,
	CONSTRAINT "chambres_numero_unique" UNIQUE("numero")
);
--> statement-breakpoint
CREATE TABLE "hotels" (
	"id" serial PRIMARY KEY NOT NULL,
	"nom" text NOT NULL,
	"adresse" text NOT NULL,
	"telephone" text NOT NULL,
	"code_unique" text NOT NULL,
	CONSTRAINT "hotels_code_unique_unique" UNIQUE("code_unique")
);
--> statement-breakpoint
CREATE TABLE "prestations" (
	"id" serial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"designation" text NOT NULL,
	"prix" numeric(10, 2) NOT NULL,
	CONSTRAINT "prestations_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "reservation_prestations" (
	"id" serial PRIMARY KEY NOT NULL,
	"reservation_id" integer NOT NULL,
	"prestation_id" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "reservations" (
	"id" serial PRIMARY KEY NOT NULL,
	"etat" "reservation_status" DEFAULT 'en_cours' NOT NULL,
	"date_reservation" timestamp DEFAULT now() NOT NULL,
	"date_arrivee" timestamp NOT NULL,
	"date_depart" timestamp NOT NULL,
	"chambre_id" integer NOT NULL,
	"client_id" integer NOT NULL,
	"prix_total" numeric(10, 2) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"nom" text NOT NULL,
	"prenom" text NOT NULL,
	"email" text NOT NULL,
	"telephone" text,
	"mot_de_passe" text NOT NULL,
	"role" "user_role" DEFAULT 'client' NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
ALTER TABLE "chambres" ADD CONSTRAINT "chambres_categorie_id_categories_id_fk" FOREIGN KEY ("categorie_id") REFERENCES "public"."categories"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservation_prestations" ADD CONSTRAINT "reservation_prestations_reservation_id_reservations_id_fk" FOREIGN KEY ("reservation_id") REFERENCES "public"."reservations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservation_prestations" ADD CONSTRAINT "reservation_prestations_prestation_id_prestations_id_fk" FOREIGN KEY ("prestation_id") REFERENCES "public"."prestations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservations" ADD CONSTRAINT "reservations_chambre_id_chambres_id_fk" FOREIGN KEY ("chambre_id") REFERENCES "public"."chambres"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservations" ADD CONSTRAINT "reservations_client_id_users_id_fk" FOREIGN KEY ("client_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;